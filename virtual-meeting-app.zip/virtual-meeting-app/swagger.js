const swaggerJsDoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const swaggerOptions = {
  swaggerDefinition: {
    openapi: '3.0.0',
    info: {
      title: 'Meeting App API',
      version: '1.0.0',
      description: 'API documentation for the Meeting App',
    },
    servers: [
      {
        url: 'http://localhost:3000', // Altere para o URL da sua aplicação
      },
    ],
  },
  apis: ['./routes/*.js'], // Onde estão localizadas as definições da API
};

const swaggerDocs = swaggerJsDoc(swaggerOptions);

const setupSwagger = (app) => {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));
};

module.exports = setupSwagger;
