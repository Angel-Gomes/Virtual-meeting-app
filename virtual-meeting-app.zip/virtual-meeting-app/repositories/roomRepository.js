const Room = require('../models/Room');

class RoomRepository {
  async createRoom(roomData) {
    const room = new Room(roomData);
    return await room.save();
  }

  async getAllRooms() {
    return await Room.find();
  }

  async findRoomById(roomId) {
    return await Room.findById(roomId);
  }

  async updateRoom(roomId, updateData) {
    return await Room.findByIdAndUpdate(roomId, updateData, { new: true });
  }

  async deleteRoom(roomId) {
    return await Room.findByIdAndDelete(roomId);
  }
}

module.exports = new RoomRepository(); // Exportando como singleton
