const User = require('../models/User');

class UserRepository {
    async getAllUsers(){
        return await UserRepository.find()
    }
    async getUserByID(id){
        return await User.findById(id)
    }
    async getUserByEmail(email){
        return await User.findOne(email)
    }
    async createUser(userData){
        const user = new User(userData);
        return await user.save()
    }

    async updateUser(userId, updateData) {
        return await User.findByIdAndUpdate(userId, updateData, { new: true });
    }

    async deleteUser(userId) {
        return await User.findByIdAndDelete(userId);
    }
}

module.exports = new UserRepository(); 