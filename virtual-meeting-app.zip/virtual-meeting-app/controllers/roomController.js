const Room = require('../models/roomModel');

exports.createRoom = async (req, res) => {
    const { name, description, capacity } = req.body;

    // Validação simples
    if (!name || !capacity) {
        return res.status(400).json({ message: 'Nome e capacidade são obrigatórios' });
    }

    try {
        const room = await Room.create({ name, description, capacity });
        res.status(201).json(room);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};


exports.listRooms = async (req, res) => {
    const rooms = await Room.find();
    res.json(rooms);
};

exports.joinRoom = async (req, res) => {
    const room = await Room.findById(req.params.id);
    if (room) {
        res.json({ message: `Joined room ${room.name}` });
    } else {
        res.status(404).json({ message: 'Room not found' });
    }
};
