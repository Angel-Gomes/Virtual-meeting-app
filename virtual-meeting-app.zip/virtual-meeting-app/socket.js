const socketIo = require('socket.io');

module.exports = (server) => {
    const io = socketIo(server, {
        cors: {
            origin: '*', // Permite qualquer origem, pode ajustar conforme necessário
            methods: ['GET', 'POST'],
        },
    });

    io.on('connection', (socket) => {
        console.log('Novo usuário conectado');

        // Evento para entrar em uma sala de reunião
        socket.on('join-room', (roomId) => {
            socket.join(roomId);
            socket.to(roomId).emit('user-connected', socket.id);
            console.log(`Usuário entrou na sala: ${roomId}`);

            // Evento de desconexão
            socket.on('disconnect', () => {
                socket.to(roomId).emit('user-disconnected', socket.id);
                console.log(`Usuário saiu da sala: ${roomId}`);
            });
        });

        // Evento de sinalização para troca de dados de áudio/vídeo
        socket.on('signal', (roomId, signalData) => {
            socket.to(roomId).emit('signal', socket.id, signalData);
        });
    });
};
